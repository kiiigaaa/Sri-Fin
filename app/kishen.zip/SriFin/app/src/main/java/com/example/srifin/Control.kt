package com.example.srifin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText

class Control : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_control)

        val rentalIncomeEditText: EditText = findViewById(R.id.editTextTextPersonName9)
        val rentalIncome = rentalIncomeEditText.text.toString()

        val overtimePayEditText: EditText = findViewById(R.id.editTextTextPersonName8)
        val overtimePay = overtimePayEditText.text.toString()

        val commissionEditText: EditText = findViewById(R.id.editTextTextPersonName7)
        val commission = commissionEditText.text.toString()

        val investmentIncomeEditText: EditText = findViewById(R.id.editTextTextPersonName2)
        val investmentIncome = investmentIncomeEditText.text.toString()

        val backButton: Button = findViewById(R.id.button18)
        backButton.setOnClickListener { rentalIncomeEditText.setText("")
            overtimePayEditText.setText("")
            commissionEditText.setText("")
            investmentIncomeEditText.setText("")
        }

        val saveButton: Button = findViewById(R.id.button17)
        saveButton.setOnClickListener {
            rentalIncomeEditText.setText("")
            overtimePayEditText.setText("")
            commissionEditText.setText("")
            investmentIncomeEditText.setText("")
        }

        val deleteButton: Button = findViewById(R.id.button15)
        deleteButton.setOnClickListener {
            rentalIncomeEditText.setText("")
            overtimePayEditText.setText("")
            commissionEditText.setText("")
            investmentIncomeEditText.setText("")
        }

    }
}
